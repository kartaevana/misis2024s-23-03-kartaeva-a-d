CHECK: 20231231-085442
ERROR: file prj.lab/CMakeLists.txt is absent
ERROR: file prj.test/CMakeLists.txt is absent
ERROR: file prj.lab/complex/CMakeLists.txt is absent
ERROR: file prj.lab/rational/CMakeLists.txt is absent
ERROR: CMake generator failed
ERROR: lab complex - test build failed
ERROR: lab complex_io - test build failed
ERROR: lab rational - test build failed
ERROR: lab rational_io - test build failed
ERROR: lab dynarr - test build failed
